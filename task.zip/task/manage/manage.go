package main

import "task/manage/service"

func main() {
	service.Start()
}
