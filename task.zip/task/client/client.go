package main

import (
	"task/client/service"
)

func main() {
	service.Start()
}
